// get dashboard

export const GET_DASHBOARD = "GET_DASHBOARD";

export const CHART_ANALYTIC = "CHART_ANALYTIC";

export const USER_HOST_ANALYTIC = "USER_HOST_ANALYTIC";
